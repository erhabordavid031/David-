# This is a CLI LMS Python App
- Godwin-Okoh Ruth